package TakeHomeProject;

import com.google.gson.*;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * This class is used for reading a json file and storing an array of Json objects
 * into a Courses object.
 */

public class ParseFile {
    private Gson gson;
    private Courses courses;

    public ParseFile() {
        gson = new Gson();
        courses = new Courses();
    }

    public Courses parseFile(String filePath) {
        try (FileReader br = new FileReader(filePath)) {

            String fileData = new String(Files.readAllBytes(Paths.get(filePath)));
            JsonParser parser = new JsonParser();
            JsonArray jsonArr = (JsonArray) parser.parse(fileData);

            for (JsonElement element : jsonArr) {
                JsonObject courseObj = element.getAsJsonObject();
                String name = courseObj.get("name").getAsString();
                courses.addCourseNode(name);
                JsonArray prerequisites = courseObj.getAsJsonArray("prerequisites");

                if (prerequisites.size() == 0) {
                    continue;
                }
                for (JsonElement ele : prerequisites) {
                    courses.addPrerequisitesEdge(name, ele.getAsString());
                }
            }

        } catch (IOException e) {
            System.out.println("Could not read the file: " + e);
        }
        return courses;
    }

}
