package TakeHomeProject;

import java.util.*;

/**
 * This class is used for storing each Json object into a CourseNode object.
 * These CourseNode objects are then put into a hash map called courseNodes;
 * Another hash map coursePreAdjacencyList is used for storing the relation
 * between a course and its list of prerequisites.
 */

public class Courses {

    /**
     * This helper class stores the name of a course as a node.
     */
    private class CourseNode {
        private String name;

        public CourseNode(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    private Map<String, CourseNode> courseNodes;
    private Map<CourseNode, List<CourseNode>> coursePreAdjacencyList;

    public Courses() {
        this.courseNodes = new HashMap<>();
        this.coursePreAdjacencyList = new HashMap<>();
    }

    /**
     * Add a CourseNode object to the Hashmap courseNodes.
     *
     * @param name
     */

    public void addCourseNode(String name) {
        CourseNode courseNode = new CourseNode(name);
        courseNodes.putIfAbsent(name, courseNode);
        coursePreAdjacencyList.putIfAbsent(courseNode, new ArrayList<>());
    }

    /**
     * Add prerequisites courses to a specific course.
     *
     * @param from
     * @param to
     */
    public void addPrerequisitesEdge(String from, String to) {
        CourseNode fromNode = courseNodes.get(from);
        CourseNode toNode = courseNodes.get(to);
        if (fromNode == null || toNode == null) {
            throw new IllegalArgumentException();
        }
        coursePreAdjacencyList.get(fromNode).add(toNode);
    }

    /**
     * This method is topologicalSort's implementation details, so set it as private
     * giving user more cleaner interface
     *
     * @param node
     * @param visited
     * @param stack
     */

    private void topologicalSort(CourseNode node, Set<CourseNode> visited, Stack<CourseNode> stack) {
        if (visited.contains(node))
            return;
        visited.add(node);
        for (CourseNode neighbour : coursePreAdjacencyList.get(node)) {
            topologicalSort(neighbour, visited, stack);
        }
        stack.push(node);

    }

    /**
     * This method is used for sorting a list courses based on it's prerequisites.
     * It will also do recursive call on the private method
     * topologicalSort(CourseNode node,Set<CourseNode> visited,Stack<CourseNode> stack)
     */
    public void topologicalSort() {
        Stack<CourseNode> stack = new Stack<>();
        Set<CourseNode> visited = new HashSet<>();

        for (CourseNode node : courseNodes.values()) {
            topologicalSort(node, visited, stack);
        }

        List<String> sortedCourses = new LinkedList<>();
        while (!stack.empty()) {
            sortedCourses.add(stack.pop().name);
        }

        for (int i = sortedCourses.size() - 1; i >= 0; i--) {
            System.out.println(sortedCourses.get(i));
        }
    }

}
