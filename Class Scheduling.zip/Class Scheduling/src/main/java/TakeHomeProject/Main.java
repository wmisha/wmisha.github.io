package TakeHomeProject;

/**
 * In Java, all action runs in Main.
 */
public class Main {

    public static void main(String[] args) {

        if (args.length == 0) {
            System.out.println("Error: No argument provided.");
            System.exit(-1);
        }
        String filePath = args[0];

        ParseFile parseFile = new ParseFile();
        Courses courses = parseFile.parseFile(filePath);
        courses.topologicalSort();
    }

}
