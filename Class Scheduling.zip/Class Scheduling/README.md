# ClassScheduling

This program is for finding an order that you can take each of the courses where all prerequisites are satisfied.

## Building and Running (using Makefile)

1. Download and install the [JDK](https://www.oracle.com/java/technologies/javase-downloads.html).

2. In a terminal open to the current directory, run `make`.

3. Run `./scheduler <FILE_NAME>`
   - For example, `./scheduler math.json`

`scheduler` is just a simple one-line shell script that tells Java to run our compiled JAR file. If you are using Windows and get a `java: command not found` error, you will need to specify the full path to `java.exe` in this script.

## Building and Running (using IntelliJ IDE)

This program was written using Java version 13.0.2 and IntelliJ. It is a Maven project.

1. Download and install the software from here: -[JDK Installation](https://www.oracle.com/java/technologies/javase-downloads.html) -[IntelliJ IDE Installation](https://www.jetbrains.com/idea/download)

2. Open this folder in the IntelliJ IDE or another one of your choice.

3. Go to `Build` -> `Build Artifacts`.

   - A window titled `Build Artifact` will pop up. Select `ClassScheduling:jar` -> `Build`.

4. In a terminal open to the current directory, run the following command: `./scheduler <FILE_NAME>`
   - For example, `./scheduler math.json`
   - If you are using Windows and get a `java: command not found` error, you will need to specify the full path to `java.exe`.

## How I designed this program

In the Java folder, I created three classes:

- ParseFile class is responsible for parsing a specific JSON file.

- Courses class is responsible for storing the JSON Data and converting a JSON data to CourseNode Object. And Store them two hashmaps.

- Main class is taking care of all the actions for running this project.

## The time complexity of this program

I use topological sorting to solve this sorting order problem.
This toplogical algrothem need loop over the nodes and adjacencyList, So run time complexity is O(V+E).

## JSON library

Because Java's built in JSON library is not very good to use. So I choose to use external library which is com.google.code.gson

To use this library, I needed do two things:

1. Go to the pom.xml file add dependecy looks like below:

![pox](pox.png)

2. Go to File -> Project Structure -> Libaraies tab -> Maven -> click + putton -> paste "com.google.code.gson:gson:2.8.5"

![JSON](JSON.png)

3. I also added the contents of this library under `/lib` so that we can include it when building using a Makefile.
